<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>New Site</title>
        <meta name="description" content="">
        <meta name="author" content="HeHexa6ty">

        <link rel='stylesheet' type="text/css" href="<?php echo e(asset('css/style.css')); ?>">
        <link rel='stylesheet' type="text/css" href="<?php echo e(asset('css/navbar.css')); ?>">
        <link rel='stylesheet' type="text/css" href="<?php echo e(asset('css/search.css')); ?>">
        <link rel='stylesheet' type="text/css" href="<?php echo e(asset('css/forms.css')); ?>">
        <link rel='stylesheet' type="text/css" href="<?php echo e(asset('css/offert.css')); ?>">
        <link rel='stylesheet' type="text/css" href="<?php echo e(asset('css/manage.css')); ?>">

    </head>
    <body>
        <nav>
            <a href='/'> <img src='<?php echo e(asset('images/no-image.jpg')); ?>' width='75px' height='75px' alt='logo'> </a>
            <ul>
                <li><a href='/?profession=barber'>Barber</a></li>
                <li><a href='/?profession=hairdresser'>Hairdresser</a></li>
                <li><a href='/?profession=cosmetic'>Cosmetic</a></li>
            </ul>
            <ul>
                <li><a href='/offerts/create'>Add offert</a></li>
                <?php if(auth()->guard()->check()): ?>
                    <li><a href='/offerts/manage'>Manage</a></li>
                    <li>
                        <form method="POST" action='/logout'>
                        <?php echo csrf_field(); ?>
                        <button type='submit' class='ffd'>Sign out</button>
                        </form>
                    </li>
                <?php else: ?>
                    <li><a href='/register' class="">Sign up</a></li>
                    <li><a href='/login'>Sign in</a></li>
                <?php endif; ?>
                
            </ul>
        </nav>
        <main>
            
            <?php echo e($slot); ?>

        </main>
    </body>
</html><?php /**PATH /var/www/html/resources/views/components/layout.blade.php ENDPATH**/ ?>