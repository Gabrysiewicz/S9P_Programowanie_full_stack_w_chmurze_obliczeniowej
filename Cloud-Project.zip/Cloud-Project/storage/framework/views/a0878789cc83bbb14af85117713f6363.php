<section id='search-bar-section'>
    <form action='/' method='get'>
        <input type='text' name='search' id='search' placeholder="Lubelskie, lublin">
        <button type='submit' id='search-submit' >Find</button>
    </form>
</section><?php /**PATH /var/www/html/resources/views/partials/_search.blade.php ENDPATH**/ ?>