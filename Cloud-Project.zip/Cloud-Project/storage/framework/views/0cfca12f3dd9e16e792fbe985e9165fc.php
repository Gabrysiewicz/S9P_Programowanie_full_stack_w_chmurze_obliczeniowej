<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->make('partials/_search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if (! (count($offerts) == 0)): ?>
        <?php $__currentLoopData = $offerts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class='offert'>
            <img src='<?php echo e($offert['profile-picture'] ? asset('storage/'. $offert['profile-picture']) : asset('images/no-image.jpg')); ?>' alt='pfp' width='150px' height='150px'>
            <ul class='offert-listing'>
                <li class='text-120'><a href='/offerts/<?php echo e($offert->id); ?>' ><?php echo e($offert->name); ?> <?php echo e($offert->surname); ?></a></li>
                
                <li><a href='/?profession=<?php echo e($offert->profession); ?>'><?php echo e($offert->profession); ?></a></li>
                <li><?php echo e($offert->voivodeship); ?>: <?php echo e($offert->city); ?></li>
            </ul>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <h1>Looks like there are no offerts...</h1>
        <h2>Log in and be the first one in here.</h2>
    <?php endif; ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?><?php /**PATH /var/www/html/resources/views/offerts/index.blade.php ENDPATH**/ ?>