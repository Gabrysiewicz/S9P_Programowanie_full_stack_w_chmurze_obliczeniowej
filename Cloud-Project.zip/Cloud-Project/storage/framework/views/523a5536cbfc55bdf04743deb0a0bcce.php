<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section id='section-manage-table'>
        <table>
            <thead>
                <tr><th>Name</th><th>Surname</th><th>Profession</th><th>View</th><th>Edit</th><th>Delete</th></tr>
            </thead>
            <tbody>
                <?php if (! ($offerts->isEmpty())): ?>
                    <?php $__currentLoopData = $offerts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr><td><?php echo e($offert->name); ?></td>
                        <td><?php echo e($offert->surname); ?></td>
                        <td><?php echo e($offert->profession); ?></td>
                        <td><a href='/offerts/<?php echo e($offert->id); ?>'><button>View</button></a></td>
                        <td><a href='/offerts/<?php echo e($offert->id); ?>/edit'><button>Edit</button></a></td>
                        <td><form method="POST" action="/offerts/<?php echo e($offert->id); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="sumbit" id='delete-offert' name='delete-offert'>Delete</button>
                        
                        </form></td>
                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6">No offerts to manage</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?><?php /**PATH /var/www/html/resources/views/offerts/manage.blade.php ENDPATH**/ ?>